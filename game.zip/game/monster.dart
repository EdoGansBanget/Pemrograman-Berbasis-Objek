import 'character.dart';

class Monster extends Character {
  String eatHuman() => 'Grr... Delicious... Yummy..';
}
