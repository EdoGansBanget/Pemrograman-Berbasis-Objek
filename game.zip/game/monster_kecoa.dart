import 'monster.dart';

class MonsterKecoa extends Monster {
  String fly() => 'Syuuung...';
}
