import 'character.dart';

class Hero extends Character {
  String killAMonster() => 'Take this!!';
}
