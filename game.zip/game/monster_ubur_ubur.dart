import 'monster.dart';

class MonsterUburUbur extends Monster {
  String swim() => 'waash... waash..';
}
