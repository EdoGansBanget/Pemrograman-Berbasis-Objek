abstract class FlyingMonster {
  String fly();
}
