import 'hero.dart';

mixin DrinkAbilityMixin on Hero {
  String drink() => 'Gluk... Gluk... Gluk...';
}
